AbrikosovSimulation — версия с внешним прямоугольным магнитом

Сборка (если Raylib и CMake установлены):
    cmake -S . -B build
    cmake --build build -j

Запуск:
    ./build/AbrikosovSimulation

Во вкладке MAGNET можно включать/выключать магнит, менять его X/Y/Z,
силу и ориентацию. Магнит должен оставаться снаружи куба (образец имеет
границы примерно X/Y = +/-10 и Z = +/-6). Золотые отрезки показывают
направление поля в нескольких точках, а красный/синий маркеры — полюса.

Физическая оговорка:
Это качественная демонстрационная модель. Магнитное поле рассчитано
приближением точечного диполя, а воздействие на вихрь — через градиент
компоненты Bz. Это не полноценное решение уравнений Гинзбурга–Ландау
и не расчёт поля с учётом экранирования сверхпроводником.


Размещение магнита:
- Вкладка MAGNET: ползунки Position X/Y/Z задают координаты от -25 до +25.
- Магнит можно размещать как снаружи, так и внутри куба.
- В 3D-сцене зажмите левую кнопку мыши на магните и перетащите его по плоскости XY.
- Высоту Z меняйте ползунком. Правой кнопкой мыши вращается камера.
- При MAGNET: OFF объект остаётся видимым (приглушённым), но поле на вихри не действует.


Режим независимых точек:
- все маркеры отображаются одним нейтральным светло-серым цветом;
- каждая точка получает собственные тепловые флуктуации;
- взаимное отталкивание точек и упругая связь между узлами отключены;
- магнитное поле, пиннинг и вязкость продолжают действовать на каждую точку отдельно.

FIELD-INDUCED VORTEX ENTRY
- The simulation starts with no vortices and the external magnet switched OFF.
- Enable the magnet and move it toward the superconducting sample.
- When the estimated field inside the sample exceeds the illustrative Hc1 threshold,
  vortex point-lines appear gradually. Moving the magnet farther away or switching
  it OFF makes them disappear gradually in this simplified demonstration.
- This is a qualitative dipole-field threshold model, not a quantitative solution
  of the Ginzburg-Landau equations or a calibrated Hc1 value in tesla.
